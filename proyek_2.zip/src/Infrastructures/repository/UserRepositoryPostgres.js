const NotFoundError = require("../../Commons/exceptions/NotFoundError");
const RegisterUser = require("../../Domains/users/entities/RegisterUser");
const { Pool } = require("pg");
const InvariantError = require("../../Commons/exceptions/InvariantError");
const RegisteredUser = require("../../Domains/users/entities/RegisteredUser");
const UserRepository = require("../../Domains/users/UserRepository");
const { nanoid } = require("nanoid");

class UserRepositoryPostgres extends UserRepository {
  /**
   * @param {Pool} pool
   * @param {nanoid} idGenerator
   */
  constructor(pool, idGenerator) {
    super();
    this._pool = pool;
    this._idGenerator = idGenerator;
  }
  /**
   * @param {string} username
   * @returns {Promise<void>}
   */
  async verifyAvailableUsername(username) {
    const query = {
      text: "SELECT username FROM users WHERE username = $1",
      values: [username],
    };
    const result = await this._pool.query(query);
    if (result.rows.length > 0) {
      throw new InvariantError("username tidak tersedia");
    }
  }

  /**
   * @param {RegisterUser} registerUser
   * @returns {Promise<RegisteredUser>}
   */
  async addUser(registerUser) {
    const { username, password, fullname } = registerUser;
    const id = `user-${this._idGenerator()}`;

    const query = {
      text: "INSERT INTO users VALUES($1, $2, $3, $4) RETURNING id, username, fullname",
      values: [id, username, password, fullname],
    };

    const result = await this._pool.query(query);

    return new RegisteredUser({ ...result.rows[0] });
  }

  /**
   * @param {string} username
   * @returns {Promise<string>}
   */
  async getPasswordByUsername(username) {
    const query = {
      text: "SELECT password FROM users WHERE username = $1",
      values: [username],
    };

    const result = await this._pool.query(query);

    if (!result.rowCount) {
      throw new InvariantError("username tidak ditemukan");
    }

    return result.rows[0].password;
  }

  /**
   * @param {string} username
   * @returns {Promise<string>}
   */
  async getIdByUsername(username) {
    const query = {
      text: "SELECT id FROM users WHERE username = $1",
      values: [username],
    };

    const result = await this._pool.query(query);

    if (!result.rowCount) {
      throw new InvariantError("user tidak ditemukan");
    }

    const { id } = result.rows[0];

    return id;
  }

  /**
   * @param {string} id
   * @returns {Promise<void>}
   */
  async mustExistOrThrowById(id) {
    /**
     * @type {import("pg").QueryConfig}
     */
    const query = {
      text: "SELECT * FROM users WHERE id = $1",
      values: [id],
    };

    const res = await this._pool.query(query);

    if (res.rows.length === 0) {
      throw new InvariantError("user tidak ditemukan");
    }
  }

  /**
   * @param {string} id
   * @returns {Promise<RegisteredUser>}
   */
  async getUserById(id) {
    /**
     * @type {import("pg").QueryConfig}
     */
    const query = {
      text: "SELECT * FROM users WHERE id = $1 ",
      values: [id],
    };
    const res = await this._pool.query(query);
    if (res.rows.length === 0) {
      throw new NotFoundError("User tidak ditemukan");
    }
    return new RegisteredUser({ ...res.rows[0] });
  }
}

module.exports = UserRepositoryPostgres;
