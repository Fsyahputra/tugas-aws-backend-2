const { nanoid } = require("nanoid");
const pool = require("../../database/postgres/pool");
const ThreadRepositoryPostgres = require("../threadRepository.js");
const UserRepositoryPostgres = require("../UserRepositoryPostgres");
const {
  registerUser,
  generateAddThreadPayload,
  getThreadById,
} = require("../../../../tests/threadRepositoryTableTest");

const service = new ThreadRepositoryPostgres(pool, nanoid);
const userService = new UserRepositoryPostgres(pool, nanoid);
beforeEach(async () => {
  /**
   * @type {import("pg").QueryConfig}
   */
  const deleteThreadQuery = {
    text: "delete from thread",
  };
  /**
   * @type {import("pg").QueryConfig}
   */
  const deleteUserQuery = {
    text: "delete from users",
  };
  await pool.query(deleteThreadQuery);
  await pool.query(deleteUserQuery);
});

afterAll(async () => {
  /**
   * @type {import("pg").QueryConfig}
   */
  const deleteThreadQuery = {
    text: "delete from thread",
  };
  /**
   * @type {import("pg").QueryConfig}
   */
  const deleteUserQuery = {
    text: "delete from users",
  };
  await pool.query(deleteThreadQuery);
  await pool.query(deleteUserQuery);
  await pool.end();
});

describe("ThreadRepositoryPostgres", () => {
  it("Should addThread", async () => {
    const newAddUser = registerUser();
    const newUser = await userService.addUser(newAddUser);
    const newThread = generateAddThreadPayload(newUser.id);
    const added = await service.addThread(newThread);
    expect(added.id).toBeDefined();
    const check = await getThreadById(added.id);
    expect(check.body).toBe(newThread.body);
    expect(check.owner).toBe(newThread.owner);
    expect(check.title).toBe(newThread.title);
  });

  it("Should getThreadById", async () => {
    const newAddUser = registerUser();
    const newUser = await userService.addUser(newAddUser);
    const newThread = generateAddThreadPayload(newUser.id);
    const added = await service.addThread(newThread);
    expect(added.id).toBeDefined();
    const addedThread = await service.getThreadById(added.id);
    expect(addedThread.id).toBe(added.id);
    expect(addedThread.body).toBe(newThread.body);
    expect(addedThread.owner).toBe(newThread.owner);
    expect(addedThread.title).toBe(newThread.title);
  });

  it("should throw err if thread did not exist", async () => {
    await expect(service.mustExistOrThrowId("invalid id")).rejects.toThrow(
      "thread tidak ditemukan",
    );
  });

  it("should not throw err if trhead existed", async () => {
    const newAddUser = registerUser();
    const newUser = await userService.addUser(newAddUser);
    const newThread = generateAddThreadPayload(newUser.id);
    const added = await service.addThread(newThread);
    expect(added.id).toBeDefined();
    await expect(service.mustExistOrThrowId(added.id)).resolves.toBeUndefined();
  });
});
