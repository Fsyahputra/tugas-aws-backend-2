const AddedThread = require("../src/Domains/thread/entities/addedThread");
const AddThread = require("../src/Domains/thread/entities/addThread");
const RegisterUser = require("../src/Domains/users/entities/RegisterUser");
const pool = require("../src/Infrastructures/database/postgres/pool");

/**
 * @param {Partial<import("../src/Domains/thread/entities/addThread").AddThreadPayload> | {}} ovd
 * @returns {RegisterUser}
 */
function registerUser(ovd = {}) {
  return new RegisterUser({
    fullname: "fadhil",
    password: "passwordKuat",
    username: "Fadhil",
    ...ovd,
  });
}

/**
 * @param {Partial<import("../src/Domains/thread/entities/addThread").AddThreadPayload>|{}} [ovd={}]
 * @param {string} owner
 */
function generateAddThreadPayload(owner, ovd = {}) {
  return new AddThread({
    body: "sebuah body",
    owner: owner,
    title: "sebuah title",
    ...ovd,
  });
}

/**
 * @param {string} id
 * @returns {Promise<AddedThread>}
 */
async function getThreadById(id) {
  /**
   * @type {import("pg").QueryConfig}
   */
  const query = {
    text: "select * from thread where id = $1",
    values: [id],
  };
  const res = await pool.query(query);
  return new AddedThread({
    ...res.rows[0],
  });
}

module.exports = {
  registerUser,
  generateAddThreadPayload,
  getThreadById,
};
