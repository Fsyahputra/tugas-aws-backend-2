const { nanoid, customAlphabet } = require("nanoid");
const NewComment = require("../src/Domains/comment/entities/newComment");
const AddThread = require("../src/Domains/thread/entities/addThread");
const RegisterUser = require("../src/Domains/users/entities/RegisterUser");
const pool = require("../src/Infrastructures/database/postgres/pool");
const AddedReplies = require("../src/Domains/replies/entities/addedReplies");
const NewReplies = require("../src/Domains/replies/entities/newReplies");

/**
 * @typedef {object} addThreadRT
 * @property {AddThread} AddThread
 */

/**
 * @typedef {object} addThreadPayload
 * @property {Partial<import("../src/Domains/thread/entities/addThread").AddThreadPayload>| {}} AddThreadPayload
 */

/**
 * @typedef {object} saveUserThreadAndCommentRT
 * @property {string} savedUserId
 * @property {string} savedThreadId
 * @property {string} savedCommentId
 */

/**
 * @param {addThreadPayload} payload
 * @param {string} owner
 * @returns {AddThread}
 */
function addThread(
  owner,
  payload = {
    AddThreadPayload: {},
  },
) {
  return new AddThread({
    body: "sebuah body",
    owner: owner,
    title: "sebuah title",
    ...payload.AddThreadPayload,
  });
}

/**
 * @param {string} threadId
 * @param {Partial<import("../src/Domains/comment/entities/type").NewCommentPayload> | {}} ovd
 * @param {string} owner
 * @returns {NewComment}
 */
function addComment(threadId, owner, ovd = {}) {
  return new NewComment({
    content: "sebuah content",
    owner: owner,
    thread_id: threadId,
    ...ovd,
  });
}

// alphabet huruf+angka+underscore saja
const nanoidSafe = customAlphabet(
  "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_",
  10,
);

/**
 * @param {Partial<import("../src/Domains/users/entities/RegisterUser").RegisterUserPayload>| {}} [ovd={}]
 * @returns {RegisterUser}
 */
function addUser(ovd = {}) {
  return new RegisterUser({
    fullname: "Muhammad Fadhil Syahputra",
    password: "password sangat kuat",
    username: nanoidSafe(), // pasti aman
    ...ovd,
  });
}

/**
 * @param {RegisterUser} payload
 * @returns {Promise<string>}
 */
async function saveUser(payload) {
  const id = nanoid();

  const registerQuery = {
    text: "INSERT INTO users VALUES($1, $2, $3, $4) returning id, username, fullname ",
    values: [id, payload.username, payload.password, payload.fullname],
  };

  const res = await pool.query(registerQuery);
  return res.rows[0].id;
}

/**
 * @param {AddThread} payload
 * @returns {Promise<string>}
 */
async function saveThread(payload) {
  const id = nanoid();

  const saveThreadQuery = {
    text: "INSERT INTO thread (id, title, body, owner) VALUES($1, $2, $3, $4) returning id",
    values: [id, payload.title, payload.body, payload.owner],
  };

  const res = await pool.query(saveThreadQuery);
  return res.rows[0].id;
}

/**
 * @param {NewComment} payload
 * @returns {Promise<string>}
 */
async function saveComment(payload) {
  const id = nanoid();

  const userUsername = {
    text: "select username from users where id = $1",
    values: [payload.owner],
  };

  const rest = await pool.query(userUsername);

  const saveCommentQuery = {
    text: "insert into comment (id, content, owner, username, thread_id, is_deleted) VALUES($1, $2, $3, $4, $5, $6) returning id",
    values: [
      id,
      payload.content,
      payload.owner,
      rest.rows[0].username,
      payload.threadId,
      false,
    ],
  };

  const res = await pool.query(saveCommentQuery);
  return res.rows[0].id;
}

/**
 * @param {string} id
 * @returns {Promise< AddedReplies >}
 */
async function getReplyById(id) {
  const getByIdQuery = {
    text: "select * from reply where id = $1",
    values: [id],
  };

  const res = await pool.query(getByIdQuery);

  return new AddedReplies({
    ...res.rows[0],
  });
}

/**
 * @param {Partial<import("../src/Domains/replies/entities/newReplies").NewRepliesPayload>|{}} [ovd={}]
 * @param {string} owner
 * @param {string} commentId
 * @param {string} threadId
 * @returns {NewReplies}
 */
function addReply(owner, commentId, threadId, ovd = {}) {
  return new NewReplies({
    comment_id: commentId,
    content: "sebuah balasan",
    owner: owner,
    thread_id: threadId,
    ...ovd,
  });
}

/**
 * @param {NewReplies} payload
 * @returns {Promise< string >}
 */
async function saveReply(payload) {
  const { commentId, content, owner, threadId } = payload;
  const id = nanoid();

  const saveReplyQuery = {
    text: "insert into reply (id, owner, content, is_delete, thread_id, comment_id) values($1, $2, $3, $4, $5, $6) returning id, owner, content, is_delete, thread_id",
    values: [id, owner, content, false, threadId, commentId],
  };

  const res = await pool.query(saveReplyQuery);
  return res.rows[0].id;
}

module.exports = {
  addThread,
  addComment,
  addUser,
  saveUser,
  saveThread,
  saveComment,
  getReplyById,
  addReply,
  saveReply,
};
