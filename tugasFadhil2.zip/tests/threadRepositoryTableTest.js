const { nanoid } = require("nanoid");
const AddedThread = require("../src/Domains/thread/entities/addedThread");
const AddThread = require("../src/Domains/thread/entities/addThread");
const RegisteredUser = require("../src/Domains/users/entities/RegisteredUser");
const RegisterUser = require("../src/Domains/users/entities/RegisterUser");
const pool = require("../src/Infrastructures/database/postgres/pool");

/**
 * @param {Partial<import("../src/Domains/thread/entities/addThread").AddThreadPayload> | {}} ovd
 * @returns {RegisterUser}
 */
function registerUser(ovd = {}) {
  return new RegisterUser({
    fullname: "fadhil",
    password: "passwordKuat",
    username: "Fadhil",
    ...ovd,
  });
}

/**
 * @param {Partial<import("../src/Domains/thread/entities/addThread").AddThreadPayload>|{}} [ovd={}]
 * @param {string} owner
 */
function generateAddThreadPayload(owner, ovd = {}) {
  return new AddThread({
    body: "sebuah body",
    owner: owner,
    title: "sebuah title",
    ...ovd,
  });
}

/**
 * @param {string} id
 * @returns {Promise<AddedThread>}
 */
async function ThreadHelperGetThreadById(id) {
  /**
   * @type {import("pg").QueryConfig}
   */
  const query = {
    text: "select * from thread where id = $1",
    values: [id],
  };
  const res = await pool.query(query);
  return new AddedThread({
    ...res.rows[0],
  });
}

/**
 * Menambahkan user ke database secara langsung (untuk test)
 * @param {RegisterUser} registerUser
 * @returns {Promise< RegisteredUser >}
 */
async function UserHelperAddUser(registerUser) {
  const { username, password, fullname } = registerUser;
  const id = `user-${nanoid()}`;

  const query = {
    text: "INSERT INTO users VALUES($1, $2, $3, $4) RETURNING id, username, fullname",
    values: [id, username, password, fullname],
  };

  const result = await pool.query(query);

  return new RegisteredUser({ ...result.rows[0] });
}

module.exports = {
  registerUser,
  generateAddThreadPayload,
  ThreadHelperGetThreadById,
  UserHelperAddUser,
};
