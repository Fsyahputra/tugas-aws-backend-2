const { nanoid } = require("nanoid");
const {
  saveUser,
  addThread,
  addUser,
  saveThread,
  addComment,
} = require("../../../../tests/replyRepositoryTestHelper");
const pool = require("../../database/postgres/pool");
const CommentRepositoryPostgres = require("../commentRepository");
const {
  getCommentById: helperGetCommentById,
  saveComment: helperSaveComment,
} = require("../../../../tests/commentRepositoryTableTestHelper");

/**
 * @typedef {object} prepareThreadRT
 * @property {string} threadOwnerId
 * @property {string} threadId
 */

beforeEach(async () => {
  /**
   * @type {import("pg").QueryConfig}
   */
  const userCleanQuery = {
    text: "delete from users",
  };

  /**
   * @type {import("pg").QueryConfig}
   */

  const threadCleasnQuery = {
    text: "delete from thread",
  };

  /**
   * @type {import("pg").QueryConfig}
   */
  const commentCleanQuery = {
    text: "delete from comment",
  };

  await pool.query(userCleanQuery);
  await pool.query(commentCleanQuery);
  await pool.query(threadCleasnQuery);
});

afterAll(async () => {
  /**
   * @type {import("pg").QueryConfig}
   */
  const userCleanQuery = {
    text: "delete from users",
  };

  /**
   * @type {import("pg").QueryConfig}
   */

  const threadCleasnQuery = {
    text: "delete from thread",
  };

  /**
   * @type {import("pg").QueryConfig}
   */
  const commentCleanQuery = {
    text: "delete from comment",
  };

  await pool.query(userCleanQuery);
  await pool.query(commentCleanQuery);
  await pool.query(threadCleasnQuery);
  await pool.end();
});

/**
 * @returns {Promise< prepareThreadRT >}
 */
async function prepareThread() {
  const newUser = addUser();
  const userId = await saveUser(newUser);
  const newThread = addThread(userId);
  const threadId = await saveThread(newThread);

  return {
    threadId,
    threadOwnerId: userId,
  };
}

/**
 * @returns {Promise<{
 * commentId : string,
 * threadId : string
 * }>}
 */
async function prepareThreadAndComment() {
  const ids = await prepareThread();
  const newUser = addUser();

  const userId = await saveUser(newUser);
  expect(userId).toBeDefined();
  const newComment = addComment(ids.threadId, userId);
  const commentId = await helperSaveComment({
    content: newComment.content,
    owner: newComment.owner,
    threadId: newComment.threadId,
    username: newUser.username,
  });
  return {
    commentId: commentId,
    threadId: ids.threadId,
  };
}

const service = new CommentRepositoryPostgres(pool, nanoid);
describe("commentRepository test", () => {
  it("should add a comment to a given thread", async () => {
    const ids = await prepareThread();
    const newUser = addUser();
    const userId = await saveUser(newUser);
    expect(userId).toBeDefined();
    /**
     * @type {import("../../../Domains/comment/commentRepository").AddPayload}
     */
    const commentPayload = {
      content: "sebuah comment",
      owner: userId,
      threadId: ids.threadId,
      username: newUser.username,
    };
    const addedComment = await service.add(commentPayload);
    const gettedComment = await helperGetCommentById(addedComment.id);
    expect(gettedComment.content).toBe(addedComment.content);
    expect(gettedComment.owner).toBe(gettedComment.owner);
    expect(gettedComment.threadId).toBe(gettedComment.threadId);
  });
  it("should delete comment ", async () => {
    const ids = await prepareThread();
    const newUser = addUser();
    const userId = await saveUser(newUser);
    /**
     * @type {import("../../../Domains/comment/commentRepository").AddPayload}
     */
    const commentPayload = {
      content: "sebuah comment",
      owner: userId,
      threadId: ids.threadId,
      username: newUser.username,
    };
    const commentId = await helperSaveComment(commentPayload);
    await service.delete(commentId);
    const gettedComment = await helperGetCommentById(commentId);
    expect(gettedComment.isDeleted).toBe(true);
  });

  it("should getCommentByid", async () => {
    const ids = await prepareThreadAndComment();
    expect(ids.commentId).toBeDefined();
    expect(ids.threadId).toBeDefined();
    const gettedComment = await service.getByCommentId(ids.commentId);
    expect(gettedComment).toBeDefined();
    expect(gettedComment.id).toBe(ids.commentId);
  });

  it("should getCommentByThreadId", async () => {
    const ids = await prepareThreadAndComment();
    expect(ids.commentId).toBeDefined();
    expect(ids.threadId).toBeDefined();
    const gettedComment = await service.getByThreadId(ids.threadId);
    expect(gettedComment).toBeDefined();
  });

  it("should throw err if comment did not exist", async () => {
    await expect(service.mustExistOrThrowId("invalid id")).rejects.toThrow(
      "komentar tidak ditemukan",
    );
  });

  it("should resolves to void if comment exist", async () => {
    const ids = await prepareThreadAndComment();
    expect(ids.commentId).toBeDefined();
    expect(ids.threadId).toBeDefined();
    await expect(
      service.mustExistOrThrowId(ids.commentId),
    ).resolves.toBeUndefined();
  });
});
